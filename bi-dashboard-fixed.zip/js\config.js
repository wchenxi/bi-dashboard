// 应用配置文件
const CONFIG = {
    // API配置
    API: {
        // AI分析接口配置
        AI_SERVICE: {
            BASE_URL: 'https://api.openai.com/v1/chat/completions', // 示例AI接口
            API_KEY: '', // 需要用户配置自己的API密钥
            MODEL: 'gpt-3.5-turbo',
            MAX_TOKENS: 1000
        },
        
        // 数据接口配置
        DATA_SERVICE: {
            BASE_URL: '/api',
            ENDPOINTS: {
                UPLOAD: '/upload',
                ANALYZE: '/analyze',
                EXPORT: '/export'
            }
        }
    },

    // 图表配置
    CHARTS: {
        COLORS: {
            PRIMARY: '#667eea',
            SECONDARY: '#764ba2',
            SUCCESS: '#28a745',
            WARNING: '#ffc107',
            DANGER: '#dc3545',
            INFO: '#17a2b8',
            LIGHT: '#f8f9fa',
            DARK: '#343a40'
        },
        
        // 销售趋势图配置
        SALES_CHART: {
            type: 'line',
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    }
                }
            }
        },

        // 类别分布图配置
        CATEGORY_CHART: {
            type: 'doughnut',
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        }
    },

    // 数据表格配置
    TABLE: {
        PAGE_SIZE: 10,
        SORT_OPTIONS: [
            { value: 'sales', label: '按销售额排序' },
            { value: 'rating', label: '按评分排序' },
            { value: 'reviews', label: '按评论数排序' },
            { value: 'bsr', label: '按BSR排名排序' }
        ]
    },

    // 本地存储键名
    STORAGE_KEYS: {
        USER_PREFERENCES: 'bi_dashboard_preferences',
        LAST_ANALYSIS: 'bi_last_analysis',
        CHART_SETTINGS: 'bi_chart_settings'
    },

    // 默认日期范围
    DATE_RANGE: {
        DEFAULT_DAYS: 30,
        MIN_DAYS: 7,
        MAX_DAYS: 365
    },

    // 错误消息
    ERROR_MESSAGES: {
        LOAD_DATA_FAILED: '数据加载失败，请检查网络连接或文件格式',
        AI_ANALYSIS_FAILED: 'AI分析失败，请检查API配置或稍后重试',
        INVALID_FILE_FORMAT: '不支持的文件格式，请上传Excel文件',
        NETWORK_ERROR: '网络连接错误，请检查网络设置',
        API_KEY_MISSING: 'AI API密钥未配置，请在设置中配置'
    },

    // 成功消息
    SUCCESS_MESSAGES: {
        DATA_LOADED: '数据加载成功',
        ANALYSIS_COMPLETED: 'AI分析完成',
        SETTINGS_SAVED: '设置已保存',
        EXPORT_SUCCESS: '数据导出成功'
    },

    // 文件上传配置
    UPLOAD: {
        ALLOWED_TYPES: [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
            'application/vnd.ms-excel' // .xls
        ],
        MAX_SIZE: 10 * 1024 * 1024, // 10MB
        SUPPORTED_COLUMNS: [
            'Product Name',
            'Category',
            'Sales',
            'Rating',
            'Reviews',
            'BSR',
            'Price',
            'Date'
        ]
    },

    // 动画配置
    ANIMATION: {
        DURATION: 300,
        EASING: 'ease-in-out'
    },

    // 主题配置
    THEME: {
        PRIMARY_COLOR: '#667eea',
        SECONDARY_COLOR: '#764ba2',
        BACKGROUND_COLOR: '#f5f7fa',
        CARD_BACKGROUND: '#ffffff',
        TEXT_PRIMARY: '#333333',
        TEXT_SECONDARY: '#666666',
        BORDER_COLOR: '#e0e0e0'
    }
};

// 导出配置
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
} 