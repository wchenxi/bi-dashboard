// 应用入口文件
class App {
    constructor() {
        this.dashboard = null;
        this.isInitialized = false;
    }

    /**
     * 初始化应用
     */
    async init() {
        try {
            console.log('🚀 正在初始化BI看板应用...');
            
            // 检查依赖
            if (!this.checkDependencies()) {
                this.showErrorMessage('应用依赖检查失败，请检查网络连接并刷新页面');
                return;
            }
            
            // 初始化仪表盘
            this.dashboard = new Dashboard();
            
            // 设置全局变量
            window.dashboard = this.dashboard;
            
            // 加载用户偏好设置
            this.loadUserPreferences();
            
            // 设置主题
            this.setupTheme();
            
            // 初始化完成
            this.isInitialized = true;
            
            console.log('✅ BI看板应用初始化完成');
            
            // 显示欢迎消息
            this.showWelcomeMessage();
            
        } catch (error) {
            console.error('❌ 应用初始化失败:', error);
            this.showErrorMessage('应用初始化失败，请刷新页面重试');
        }
    }

    /**
     * 检查依赖
     */
    checkDependencies() {
        // 检查Chart.js
        if (typeof Chart === 'undefined') {
            console.error('Chart.js 未加载，请检查网络连接');
            return false;
        }

        // 检查Font Awesome
        if (!document.querySelector('.fas')) {
            console.warn('Font Awesome 图标可能未正确加载');
        }

        // 检查现代浏览器特性
        if (!window.fetch) {
            console.error('当前浏览器不支持 fetch API');
            return false;
        }

        if (!window.localStorage) {
            console.error('当前浏览器不支持 localStorage');
            return false;
        }
        
        return true;
    }

    /**
     * 加载用户偏好设置
     */
    loadUserPreferences() {
        try {
            const preferences = Utils.storage.get(CONFIG.STORAGE_KEYS.USER_PREFERENCES, {});
            
            // 应用主题设置
            if (preferences.theme) {
                this.setTheme(preferences.theme);
            }
            
            // 应用图表设置
            if (preferences.chartSettings) {
                this.applyChartSettings(preferences.chartSettings);
            }
            
        } catch (error) {
            console.warn('加载用户偏好设置失败:', error);
        }
    }

    /**
     * 设置主题
     */
    setupTheme() {
        // 检测系统主题偏好
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const savedTheme = Utils.storage.get('theme', prefersDark ? 'dark' : 'light');
        
        this.setTheme(savedTheme);
        
        // 监听系统主题变化
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            const newTheme = e.matches ? 'dark' : 'light';
            this.setTheme(newTheme);
        });
    }

    /**
     * 设置主题
     * @param {string} theme - 主题名称
     */
    setTheme(theme) {
        const root = document.documentElement;
        
        if (theme === 'dark') {
            root.classList.add('dark-theme');
            root.setAttribute('data-theme', 'dark');
        } else {
            root.classList.remove('dark-theme');
            root.setAttribute('data-theme', 'light');
        }
        
        // 更新图表主题
        if (this.dashboard && this.dashboard.chartManager) {
            this.dashboard.chartManager.setTheme(theme);
        }
        
        // 保存主题设置
        Utils.storage.set('theme', theme);
        
        // 保存到用户偏好
        const preferences = Utils.storage.get(CONFIG.STORAGE_KEYS.USER_PREFERENCES, {});
        preferences.theme = theme;
        Utils.storage.set(CONFIG.STORAGE_KEYS.USER_PREFERENCES, preferences);
    }

    /**
     * 应用图表设置
     * @param {Object} settings - 图表设置
     */
    applyChartSettings(settings) {
        if (this.dashboard && this.dashboard.chartManager) {
            // 应用图表配置
            Object.keys(settings).forEach(key => {
                if (CONFIG.CHARTS[key]) {
                    Object.assign(CONFIG.CHARTS[key], settings[key]);
                }
            });
        }
    }

    /**
     * 显示欢迎消息
     */
    showWelcomeMessage() {
        setTimeout(() => {
            Utils.showNotification('欢迎使用亚马逊电商BI看板！', 'success', 5000);
        }, 1000);
    }

    /**
     * 显示错误消息
     * @param {string} message - 错误消息
     */
    showErrorMessage(message) {
        const errorContainer = document.createElement('div');
        errorContainer.className = 'error-container';
        errorContainer.innerHTML = `
            <div class="error-content">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>应用错误</h3>
                <p>${message}</p>
                <button onclick="location.reload()">刷新页面</button>
            </div>
        `;
        
        errorContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 99999;
            color: white;
            text-align: center;
        `;
        
        document.body.appendChild(errorContainer);
    }

    /**
     * 获取应用状态
     * @returns {Object} 应用状态
     */
    getStatus() {
        return {
            initialized: this.isInitialized,
            dashboard: !!this.dashboard,
            theme: Utils.storage.get('theme', 'light'),
            version: '1.0.0',
            timestamp: new Date().toISOString()
        };
    }

    /**
     * 重置应用
     */
    reset() {
        try {
            // 清除本地存储
            Utils.storage.clear();
            
            // 重新初始化
            this.init();
            
            Utils.showNotification('应用已重置', 'success');
        } catch (error) {
            console.error('重置应用失败:', error);
            Utils.showNotification('重置失败，请刷新页面', 'error');
        }
    }

    /**
     * 导出应用配置
     * @returns {Object} 应用配置
     */
    exportConfig() {
        return {
            config: CONFIG,
            userPreferences: Utils.storage.get(CONFIG.STORAGE_KEYS.USER_PREFERENCES, {}),
            theme: Utils.storage.get('theme', 'light'),
            timestamp: new Date().toISOString()
        };
    }

    /**
     * 导入应用配置
     * @param {Object} config - 应用配置
     */
    importConfig(config) {
        try {
            if (config.userPreferences) {
                Utils.storage.set(CONFIG.STORAGE_KEYS.USER_PREFERENCES, config.userPreferences);
            }
            
            if (config.theme) {
                this.setTheme(config.theme);
            }
            
            Utils.showNotification('配置导入成功', 'success');
        } catch (error) {
            console.error('导入配置失败:', error);
            Utils.showNotification('配置导入失败', 'error');
        }
    }
}

// 全局应用实例
let app;

// 页面加载完成后初始化应用
document.addEventListener('DOMContentLoaded', () => {
    // 防止重复初始化
    if (window.app) {
        console.warn('应用已经初始化，跳过重复初始化');
        return;
    }
    
    app = new App();
    app.init().catch(error => {
        console.error('应用启动失败:', error);
    });
});

// 页面卸载前清理资源
window.addEventListener('beforeunload', () => {
    if (app && app.dashboard) {
        // 清理图表资源
        app.dashboard.chartManager.destroyAllCharts();
    }
});

// 全局错误处理
window.addEventListener('error', (event) => {
    console.error('全局错误:', event.error);
    // 防止错误导致页面刷新
    event.preventDefault();
});

// 未处理的Promise拒绝处理
window.addEventListener('unhandledrejection', (event) => {
    console.error('未处理的Promise拒绝:', event.reason);
    // 防止Promise拒绝导致页面刷新
    event.preventDefault();
});

// 导出应用类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = App;
} 