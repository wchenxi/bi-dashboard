// 图表管理模块
class ChartManager {
    constructor() {
        this.charts = {};
        this.chartColors = [
            '#667eea', '#764ba2', '#f093fb', '#f5576c',
            '#4facfe', '#00f2fe', '#43e97b', '#38f9d7',
            '#fa709a', '#fee140', '#a8edea', '#fed6e3',
            '#ffecd2', '#fcb69f', '#ff9a9e', '#fecfef'
        ];
    }

    /**
     * 初始化销售趋势图
     * @param {string} canvasId - Canvas元素ID
     * @param {Array} data - 销售数据
     */
    initSalesChart(canvasId, data = []) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        // 销毁现有图表
        if (this.charts.salesChart) {
            this.charts.salesChart.destroy();
        }

        const chartData = this.prepareSalesChartData(data);
        
        this.charts.salesChart = new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                aspectRatio: 2,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: function(context) {
                                return `销售额: $${Utils.formatNumber(context.parsed.y)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '$' + Utils.formatNumber(value);
                            }
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    }

    /**
     * 准备销售趋势图数据
     * @param {Array} data - 原始数据
     * @returns {Object} 图表数据对象
     */
    prepareSalesChartData(data) {
        const labels = data.map(item => Utils.formatDate(item.date, 'MM-DD'));
        const salesData = data.map(item => item.sales);

        return {
            labels: labels,
            datasets: [{
                label: '销售额',
                data: salesData,
                borderColor: CONFIG.CHARTS.COLORS.PRIMARY,
                backgroundColor: this.hexToRgba(CONFIG.CHARTS.COLORS.PRIMARY, 0.1),
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: CONFIG.CHARTS.COLORS.PRIMARY,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        };
    }

    /**
     * 初始化类别分布图
     * @param {string} canvasId - Canvas元素ID
     * @param {Array} data - 类别数据
     */
    initCategoryChart(canvasId, data = []) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        // 销毁现有图表
        if (this.charts.categoryChart) {
            this.charts.categoryChart.destroy();
        }

        const chartData = this.prepareCategoryChartData(data);
        
        this.charts.categoryChart = new Chart(ctx, {
            type: 'doughnut',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                aspectRatio: 1,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            generateLabels: function(chart) {
                                const data = chart.data;
                                if (data.labels.length && data.datasets.length) {
                                    return data.labels.map((label, i) => {
                                        const dataset = data.datasets[0];
                                        const value = dataset.data[i];
                                        const total = dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((value / total) * 100).toFixed(1);
                                        
                                        return {
                                            text: `${label} (${percentage}%)`,
                                            fillStyle: dataset.backgroundColor[i],
                                            strokeStyle: dataset.borderColor[i],
                                            lineWidth: 2,
                                            pointStyle: 'circle',
                                            hidden: false,
                                            index: i
                                        };
                                    });
                                }
                                return [];
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: $${Utils.formatNumber(value)} (${percentage}%)`;
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    }

    /**
     * 准备类别分布图数据
     * @param {Array} data - 原始数据
     * @returns {Object} 图表数据对象
     */
    prepareCategoryChartData(data) {
        const labels = data.map(item => item.name);
        const salesData = data.map(item => item.totalSales);
        const colors = this.generateColors(labels.length);

        return {
            labels: labels,
            datasets: [{
                data: salesData,
                backgroundColor: colors,
                borderColor: colors.map(color => this.darkenColor(color, 0.2)),
                borderWidth: 2,
                hoverOffset: 4
            }]
        };
    }

    /**
     * 更新销售趋势图
     * @param {Array} data - 新数据
     */
    updateSalesChart(data) {
        if (this.charts.salesChart) {
            const chartData = this.prepareSalesChartData(data);
            this.charts.salesChart.data = chartData;
            this.charts.salesChart.update('active');
        }
    }

    /**
     * 更新类别分布图
     * @param {Array} data - 新数据
     */
    updateCategoryChart(data) {
        if (this.charts.categoryChart) {
            const chartData = this.prepareCategoryChartData(data);
            this.charts.categoryChart.data = chartData;
            this.charts.categoryChart.update('active');
        }
    }

    /**
     * 初始化品牌分布图
     * @param {string} canvasId - Canvas元素ID
     * @param {Array} data - 品牌数据
     */
    initBrandChart(canvasId, data = []) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        // 销毁现有图表
        if (this.charts.brandChart) {
            this.charts.brandChart.destroy();
        }

        const chartData = this.prepareBrandChartData(data);
        
        this.charts.brandChart = new Chart(ctx, {
            type: 'doughnut',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                aspectRatio: 1,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            usePointStyle: true,
                            padding: 20,
                            generateLabels: function(chart) {
                                const data = chart.data;
                                if (data.labels.length && data.datasets.length) {
                                    return data.labels.map((label, i) => {
                                        const dataset = data.datasets[0];
                                        const value = dataset.data[i];
                                        const total = dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = ((value / total) * 100).toFixed(1);
                                        return {
                                            text: `${label} (${percentage}%)`,
                                            fillStyle: dataset.backgroundColor[i],
                                            strokeStyle: dataset.borderColor[i],
                                            lineWidth: 2,
                                            pointStyle: 'circle'
                                        };
                                    });
                                }
                                return [];
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: $${Utils.formatNumber(value)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    /**
     * 准备品牌分布图数据
     * @param {Array} data - 原始数据
     * @returns {Object} 图表数据对象
     */
    prepareBrandChartData(data) {
        console.log('📊 准备品牌图表数据:', data);
        
        const labels = data.map(item => item.name);
        const revenueData = data.map(item => item.totalRevenue);
        const colors = this.generateColors(labels.length);

        console.log('🏷️ 品牌标签:', labels);
        console.log('💰 品牌销售额:', revenueData);

        return {
            labels: labels,
            datasets: [{
                label: '品牌销售额',
                data: revenueData,
                backgroundColor: colors,
                borderColor: colors.map(color => this.darkenColor(color, 0.2)),
                borderWidth: 2,
                hoverOffset: 4
            }]
        };
    }

    /**
     * 生成颜色数组
     * @param {number} count - 颜色数量
     * @returns {Array} 颜色数组
     */
    generateColors(count) {
        const colors = [];
        for (let i = 0; i < count; i++) {
            colors.push(this.chartColors[i % this.chartColors.length]);
        }
        return colors;
    }

    /**
     * 将十六进制颜色转换为RGBA
     * @param {string} hex - 十六进制颜色
     * @param {number} alpha - 透明度
     * @returns {string} RGBA颜色
     */
    hexToRgba(hex, alpha = 1) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    /**
     * 加深颜色
     * @param {string} hex - 十六进制颜色
     * @param {number} factor - 加深因子
     * @returns {string} 加深后的颜色
     */
    darkenColor(hex, factor) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        
        const newR = Math.max(0, Math.floor(r * (1 - factor)));
        const newG = Math.max(0, Math.floor(g * (1 - factor)));
        const newB = Math.max(0, Math.floor(b * (1 - factor)));
        
        return `#${newR.toString(16).padStart(2, '0')}${newG.toString(16).padStart(2, '0')}${newB.toString(16).padStart(2, '0')}`;
    }

    /**
     * 创建柱状图
     * @param {string} canvasId - Canvas元素ID
     * @param {Array} data - 数据
     * @param {Object} options - 配置选项
     */
    createBarChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        const chartId = `barChart_${Utils.generateId()}`;
        
        this.charts[chartId] = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: options.label || '数据',
                    data: data.values,
                    backgroundColor: this.generateColors(data.labels.length),
                    borderColor: this.generateColors(data.labels.length).map(color => this.darkenColor(color, 0.2)),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: options.showLegend !== false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${Utils.formatNumber(context.parsed.y)}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    }
                }
            }
        });

        return chartId;
    }

    /**
     * 创建饼图
     * @param {string} canvasId - Canvas元素ID
     * @param {Array} data - 数据
     * @param {Object} options - 配置选项
     */
    createPieChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        const chartId = `pieChart_${Utils.generateId()}`;
        
        this.charts[chartId] = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: this.generateColors(data.labels.length),
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: options.legendPosition || 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${Utils.formatNumber(value)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });

        return chartId;
    }

    /**
     * 创建雷达图
     * @param {string} canvasId - Canvas元素ID
     * @param {Array} data - 数据
     * @param {Object} options - 配置选项
     */
    createRadarChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return;

        const chartId = `radarChart_${Utils.generateId()}`;
        
        this.charts[chartId] = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: options.label || '数据',
                    data: data.values,
                    backgroundColor: this.hexToRgba(CONFIG.CHARTS.COLORS.PRIMARY, 0.2),
                    borderColor: CONFIG.CHARTS.COLORS.PRIMARY,
                    borderWidth: 2,
                    pointBackgroundColor: CONFIG.CHARTS.COLORS.PRIMARY,
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: options.showLegend !== false
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        },
                        pointLabels: {
                            font: {
                                size: 12
                            }
                        }
                    }
                }
            }
        });

        return chartId;
    }

    /**
     * 更新图表数据
     * @param {string} chartId - 图表ID
     * @param {Object} newData - 新数据
     */
    updateChart(chartId, newData) {
        if (this.charts[chartId]) {
            this.charts[chartId].data = newData;
            this.charts[chartId].update('active');
        }
    }

    /**
     * 销毁图表
     * @param {string} chartId - 图表ID
     */
    destroyChart(chartId) {
        if (this.charts[chartId]) {
            this.charts[chartId].destroy();
            delete this.charts[chartId];
        }
    }

    /**
     * 销毁所有图表
     */
    destroyAllCharts() {
        Object.keys(this.charts).forEach(chartId => {
            this.destroyChart(chartId);
        });
    }

    /**
     * 获取图表实例
     * @param {string} chartId - 图表ID
     * @returns {Chart|null} 图表实例
     */
    getChart(chartId) {
        return this.charts[chartId] || null;
    }

    /**
     * 导出图表为图片
     * @param {string} chartId - 图表ID
     * @param {string} format - 图片格式 ('png', 'jpeg')
     * @returns {string} 图片数据URL
     */
    exportChartAsImage(chartId, format = 'png') {
        const chart = this.getChart(chartId);
        if (!chart) return null;

        return chart.toBase64Image(`image/${format}`);
    }

    /**
     * 设置图表主题
     * @param {string} theme - 主题名称 ('light', 'dark')
     */
    setTheme(theme) {
        const isDark = theme === 'dark';
        const textColor = isDark ? '#ffffff' : '#333333';
        const gridColor = isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';

        Object.values(this.charts).forEach(chart => {
            if (chart.options.scales) {
                Object.values(chart.options.scales).forEach(scale => {
                    if (scale.grid) {
                        scale.grid.color = gridColor;
                    }
                    if (scale.ticks) {
                        scale.ticks.color = textColor;
                    }
                });
            }
            chart.update('none');
        });
    }
}

// 导出图表管理类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChartManager;
} 