// 数据处理模块
class DataProcessor {
    constructor() {
        this.rawData = [];
        this.processedData = [];
        this.categories = [];
        this.dateRange = {
            start: null,
            end: null
        };
    }

    /**
     * 处理Excel文件数据
     * @param {Array} rawData - 原始Excel数据
     * @returns {Promise<Object>} 处理后的数据
     */
    async processExcelData(rawData) {
        try {
            Utils.showLoading(true, '正在处理数据...');
            
            this.rawData = rawData;
            const result = this.parseExcelData(rawData);
            
            if (!result.success) {
                Utils.showLoading(false);
                throw new Error('数据处理失败: ' + result.error);
            }

            this.processedData = result.data;
            this.categories = result.categories;
            this.dateRange = result.dateRange;
            
            // 数据验证
            this.validateData();
            
            Utils.showLoading(false);
            
            return {
                success: true,
                data: this.processedData,
                categories: this.categories,
                summary: this.generateSummary(),
                dateRange: this.dateRange
            };
            
        } catch (error) {
            Utils.showLoading(false);
            console.error('数据处理错误:', error);
            throw new Error('数据处理失败: ' + error.message);
        }
    }

    /**
     * 解析Excel数据
     * @param {Array} rawData - 原始数据
     * @returns {Array} 解析后的数据
     */
    parseExcelData(rawData) {
        if (!Array.isArray(rawData) || rawData.length === 0) {
            return { success: false, error: '无效的数据格式' };
        }

        // 获取表头
        const headers = rawData[0];
        const dataRows = rawData.slice(1);

        console.log('📊 开始解析Excel数据...');
        console.log('📋 表头行数:', headers.length);
        console.log('📋 数据行数:', dataRows.length);

        // 映射列名
        const columnMap = this.mapColumns(headers);

        // 调试：显示前几行的品牌数据
        console.log('🔍 调试前5行的品牌数据:');
        for (let i = 0; i < Math.min(5, dataRows.length); i++) {
            const row = dataRows[i];
            const brandIndex = columnMap.brand;
            const brandValue = brandIndex !== undefined ? row[brandIndex] : '未映射';
            console.log(`  行${i + 1}: brand索引=${brandIndex}, brand值="${brandValue}"`);
        }

        const processedData = dataRows.map((row, index) => {
            const processedRow = {
                id: Utils.generateId(),
                index: index + 1
            };

            // 处理每一列数据
            Object.keys(columnMap).forEach(key => {
                const columnIndex = columnMap[key];
                let value = row[columnIndex];

                // 根据列类型进行数据转换
                switch (key) {
                    case 'productName':
                        processedRow.productName = this.cleanString(value);
                        break;
                    case 'brand':
                        processedRow.brand = this.cleanString(value);
                        break;
                    case 'asin':
                        processedRow.asin = this.cleanString(value);
                        break;
                    case 'category':
                        processedRow.category = this.cleanString(value);
                        break;
                    case 'mainCategory':
                        processedRow.mainCategory = this.cleanString(value);
                        break;
                    case 'subCategory':
                        processedRow.subCategory = this.cleanString(value);
                        break;
                    case 'monthlySales':
                        processedRow.monthlySales = this.parseNumber(value);
                        break;
                    case 'monthlyRevenue':
                        processedRow.monthlyRevenue = this.parseNumber(value);
                        break;
                    case 'mainCategoryBSR':
                        processedRow.mainCategoryBSR = this.parseNumber(value);
                        break;
                    case 'subCategoryBSR':
                        processedRow.subCategoryBSR = this.parseNumber(value);
                        break;
                    case 'rating':
                        processedRow.rating = this.parseNumber(value, 1);
                        break;
                    case 'reviewCount':
                        processedRow.reviewCount = this.parseNumber(value);
                        break;
                    case 'reviewRate':
                        processedRow.reviewRate = this.parseNumber(value);
                        break;
                    case 'price':
                        processedRow.price = this.parseNumber(value);
                        break;
                    case 'primePrice':
                        processedRow.primePrice = this.parseNumber(value);
                        break;
                    case 'listingDate':
                        processedRow.listingDate = this.parseDate(value);
                        break;
                    case 'listingDays':
                        processedRow.listingDays = this.parseNumber(value);
                        break;
                }
            });

            // 计算衍生指标
            processedRow.conversionRate = this.calculateConversionRate(processedRow);
            processedRow.salesRank = this.calculateSalesRank(processedRow);

            return processedRow;
        }).filter(row => row.productName); // 过滤空行

        console.log(`✅ 数据处理完成: 有效行${processedData.length}`);

        if (processedData.length === 0) {
            return { success: false, error: '没有有效数据' };
        }

        // 生成汇总信息
        const summary = this.generateSummary(processedData);
        const categories = this.getCategories(processedData);
        const dateRange = this.getDateRange(processedData);

        return {
            success: true,
            data: processedData,
            categories: categories,
            summary: summary,
            dateRange: dateRange
        };
    }

    /**
     * 获取类别信息
     * @param {Array} data - 处理后的数据
     * @returns {Array} 类别数组
     */
    getCategories(data) {
        const categorySet = new Set();
        data.forEach(row => {
            if (row.category) {
                categorySet.add(row.category);
            }
        });
        return Array.from(categorySet).sort();
    }

    /**
     * 获取日期范围
     * @param {Array} data - 处理后的数据
     * @returns {Object} 日期范围对象
     */
    getDateRange(data) {
        const dates = data
            .map(row => row.listingDate)
            .filter(date => date !== null)
            .sort((a, b) => a - b);

        return {
            start: dates.length > 0 ? dates[0] : null,
            end: dates.length > 0 ? dates[dates.length - 1] : null
        };
    }

    /**
     * 映射Excel列名到标准字段名
     * @param {Array} headers - 表头数组
     * @returns {Object} 列映射对象
     */
        mapColumns(headers) {
        console.log('🔍 开始映射列名...');
        console.log('📋 所有表头:', headers);
        
        const columnMap = {};
        const requiredColumns = ['productName', 'monthlyRevenue'];
        
        // 精确匹配映射
        const exactMappings = {
            'ASIN': 'asin',
            '品牌': 'brand',
            '商品标题': 'productName',
            '类目路径': 'category',
            '大类目': 'mainCategory',
            '大类BSR': 'mainCategoryBSR',
            '小类目': 'subCategory',
            '小类BSR': 'subCategoryBSR',
            '月销量': 'monthlySales',
            '月销售额($)': 'monthlyRevenue',
            '价格($)': 'price',
            'Prime价格($)': 'primePrice',
            '评分数': 'reviewCount',
            '评分': 'rating',
            '留评率': 'reviewRate',
            '上架时间': 'listingDate',
            '上架天数': 'listingDays'
        };
        
        // 先进行精确匹配
        headers.forEach((header, index) => {
            const cleanedHeader = this.cleanString(header);
            console.log(`🔧 处理列头 ${index}: "${header}" -> "${cleanedHeader}"`);
            
            if (exactMappings[cleanedHeader]) {
                const fieldName = exactMappings[cleanedHeader];
                columnMap[fieldName] = index;
                console.log(`✅ 映射成功: ${fieldName} -> 列 ${index} (${cleanedHeader})`);
            }
        });
        
        // 检查是否所有必需列都已映射
        const missingColumns = requiredColumns.filter(col => !(col in columnMap));
        
        if (missingColumns.length > 0) {
            console.log(`⚠️ 缺少必需列: ${missingColumns.join(', ')}`);
            
            // 对缺失的列进行模糊匹配
            missingColumns.forEach(missingCol => {
                headers.forEach((header, index) => {
                    const cleanedHeader = this.cleanString(header);
                    
                    // 模糊匹配规则
                    if (missingCol === 'productName' && cleanedHeader.includes('标题')) {
                        columnMap[missingCol] = index;
                        console.log(`✅ 模糊匹配成功: ${missingCol} -> 列 ${index} (${cleanedHeader})`);
                    } else if (missingCol === 'monthlyRevenue' && cleanedHeader.includes('销售额')) {
                        columnMap[missingCol] = index;
                        console.log(`✅ 模糊匹配成功: ${missingCol} -> 列 ${index} (${cleanedHeader})`);
                    }
                });
            });
        }
        
        console.log('📊 最终列映射:', columnMap);
        
        // 验证映射结果
        const allRequired = requiredColumns.every(col => col in columnMap);
        if (allRequired) {
            console.log('✅ 列映射完成，所有必要列都已找到');
        } else {
            console.log('❌ 列映射失败，缺少必要列');
        }
        
        return columnMap;
    }

    /**
     * 清理字符串数据
     * @param {*} value - 原始值
     * @returns {string} 清理后的字符串
     */
    cleanString(value) {
        if (value === null || value === undefined) return '';
        const cleaned = String(value).trim();
        
        // 调试品牌数据（只对品牌列）
        if (cleaned && cleaned.length > 0 && cleaned.length < 50) {
            console.log('🔧 清理字符串:', {
                original: value,
                cleaned: cleaned,
                length: cleaned.length
            });
        }
        
        return cleaned;
    }

    /**
     * 解析数字
     * @param {*} value - 原始值
     * @param {number} decimals - 小数位数
     * @returns {number} 解析后的数字
     */
    parseNumber(value, decimals = 0) {
        if (value === null || value === undefined || value === '') return 0;
        
        // 移除货币符号和逗号
        let cleanValue = String(value).replace(/[$,¥€£]/g, '').replace(/,/g, '');
        
        // 提取数字
        const match = cleanValue.match(/[\d.-]+/);
        if (!match) return 0;
        
        const num = parseFloat(match[0]);
        return isNaN(num) ? 0 : Number(num.toFixed(decimals));
    }

    /**
     * 解析日期
     * @param {*} value - 原始值
     * @returns {Date|null} 解析后的日期
     */
    parseDate(value) {
        if (!value) return null;
        
        const date = new Date(value);
        return isNaN(date.getTime()) ? null : date;
    }

    /**
     * 计算转化率
     * @param {Object} row - 数据行
     * @returns {number} 转化率
     */
    calculateConversionRate(row) {
        if (!row.reviewCount || row.reviewCount === 0) return 0;
        // 假设转化率 = 评论数 / 1000（简化计算）
        return Math.min((row.reviewCount / 1000) * 100, 100);
    }

    /**
     * 计算销售排名
     * @param {Object} row - 数据行
     * @returns {number} 销售排名
     */
    calculateSalesRank(row) {
        // 基于月销售额计算排名（简化算法）
        if (!row.monthlyRevenue || row.monthlyRevenue === 0) return 999999;
        return Math.floor(1000000 / row.monthlyRevenue);
    }

    /**
     * 验证数据
     */
    validateData() {
        if (this.processedData.length === 0) {
            throw new Error('没有有效的数据行');
        }

        // 检查数据完整性
        const invalidRows = this.processedData.filter(row => 
            !row.productName || !row.category
        );

        if (invalidRows.length > 0) {
            console.warn(`发现 ${invalidRows.length} 行无效数据`);
        }
    }

    /**
     * 生成数据摘要
     * @returns {Object} 数据摘要
     */
    generateSummary() {
        const totalProducts = this.processedData.length;
        const totalRevenue = this.processedData.reduce((sum, row) => sum + (row.monthlyRevenue || 0), 0);
        const totalSales = this.processedData.reduce((sum, row) => sum + (row.monthlySales || 0), 0);
        const avgRating = this.processedData.reduce((sum, row) => sum + (row.rating || 0), 0) / totalProducts;
        const totalReviews = this.processedData.reduce((sum, row) => sum + (row.reviewCount || 0), 0);
        const avgPrice = this.processedData.reduce((sum, row) => sum + (row.price || 0), 0) / totalProducts;
        const avgBSR = this.processedData.reduce((sum, row) => sum + (row.subCategoryBSR || 0), 0) / totalProducts;

        return {
            totalProducts,
            totalRevenue,
            totalSales,
            avgRating: Number(avgRating.toFixed(2)),
            totalReviews,
            avgPrice: Number(avgPrice.toFixed(2)),
            avgBSR: Number(avgBSR.toFixed(0)),
            categories: this.categories.length,
            brands: this.getBrands().length
        };
    }

    /**
     * 按条件筛选数据
     * @param {Object} filters - 筛选条件
     * @returns {Array} 筛选后的数据
     */
    filterData(filters = {}) {
        let filteredData = [...this.processedData];

        // 按类别筛选
        if (filters.category && filters.category !== 'all') {
            filteredData = filteredData.filter(row => row.category === filters.category);
        }

        // 按日期范围筛选
        if (filters.startDate && filters.endDate) {
            filteredData = filteredData.filter(row => {
                if (!row.date) return false;
                return row.date >= new Date(filters.startDate) && 
                       row.date <= new Date(filters.endDate);
            });
        }

        // 按销售额范围筛选
        if (filters.minSales !== undefined) {
            filteredData = filteredData.filter(row => row.monthlyRevenue >= filters.minSales);
        }
        if (filters.maxSales !== undefined) {
            filteredData = filteredData.filter(row => row.monthlyRevenue <= filters.maxSales);
        }

        // 按评分筛选
        if (filters.minRating !== undefined) {
            filteredData = filteredData.filter(row => row.rating >= filters.minRating);
        }

        // 按关键词搜索
        if (filters.search) {
            const searchTerm = filters.search.toLowerCase();
            filteredData = filteredData.filter(row => 
                row.productName.toLowerCase().includes(searchTerm) ||
                row.category.toLowerCase().includes(searchTerm)
            );
        }

        // 排序处理
        if (filters.sortBy) {
            filteredData = this.sortData(filteredData, filters.sortBy);
        }

        return filteredData;
    }

    /**
     * 排序数据
     * @param {Array} data - 要排序的数据
     * @param {string} sortBy - 排序字段
     * @returns {Array} 排序后的数据
     */
    sortData(data, sortBy) {
        return [...data].sort((a, b) => {
            let aValue, bValue;
            
            switch (sortBy) {
                case 'sales-asc':
                    aValue = a.monthlyRevenue || 0;
                    bValue = b.monthlyRevenue || 0;
                    return aValue - bValue;
                case 'sales-desc':
                    aValue = a.monthlyRevenue || 0;
                    bValue = b.monthlyRevenue || 0;
                    return bValue - aValue;
                case 'rating-asc':
                    aValue = a.rating || 0;
                    bValue = b.rating || 0;
                    return aValue - bValue;
                case 'rating-desc':
                    aValue = a.rating || 0;
                    bValue = b.rating || 0;
                    return bValue - aValue;
                case 'reviews-asc':
                    aValue = a.reviewCount || 0;
                    bValue = b.reviewCount || 0;
                    return aValue - bValue;
                case 'reviews-desc':
                    aValue = a.reviewCount || 0;
                    bValue = b.reviewCount || 0;
                    return bValue - aValue;
                case 'bsr-asc':
                    aValue = a.subCategoryBSR || 0;
                    bValue = b.subCategoryBSR || 0;
                    return aValue - bValue;
                case 'bsr-desc':
                    aValue = a.subCategoryBSR || 0;
                    bValue = b.subCategoryBSR || 0;
                    return bValue - aValue;
                case 'price-asc':
                    aValue = a.price || 0;
                    bValue = b.price || 0;
                    return aValue - bValue;
                case 'price-desc':
                    aValue = a.price || 0;
                    bValue = b.price || 0;
                    return bValue - aValue;
                case 'name-asc':
                    aValue = (a.productName || '').toLowerCase();
                    bValue = (b.productName || '').toLowerCase();
                    return aValue.localeCompare(bValue);
                case 'name-desc':
                    aValue = (a.productName || '').toLowerCase();
                    bValue = (b.productName || '').toLowerCase();
                    return bValue.localeCompare(aValue);
                case 'category-asc':
                    aValue = (a.mainCategory || a.category || '').toLowerCase();
                    bValue = (b.mainCategory || b.category || '').toLowerCase();
                    return aValue.localeCompare(bValue);
                case 'category-desc':
                    aValue = (a.mainCategory || a.category || '').toLowerCase();
                    bValue = (b.mainCategory || b.category || '').toLowerCase();
                    return bValue.localeCompare(aValue);
                default:
                    return 0;
            }
        });
    }

    /**
     * 获取类别统计
     * @returns {Array} 类别统计数据
     */
    getCategoryStats() {
        const categoryStats = {};
        
        this.processedData.forEach(row => {
            const category = row.mainCategory || row.category;
            if (!categoryStats[category]) {
                categoryStats[category] = {
                    name: category,
                    count: 0,
                    totalRevenue: 0,
                    totalSales: 0,
                    avgRating: 0,
                    totalReviews: 0,
                    avgBSR: 0
                };
            }
            
            categoryStats[category].count++;
            categoryStats[category].totalRevenue += row.monthlyRevenue || 0;
            categoryStats[category].totalSales += row.monthlySales || 0;
            categoryStats[category].totalReviews += row.reviewCount || 0;
        });

        // 计算平均评分和BSR
        Object.keys(categoryStats).forEach(category => {
            const stats = categoryStats[category];
            const categoryRows = this.processedData.filter(row => (row.mainCategory || row.category) === category);
            const totalRating = categoryRows.reduce((sum, row) => sum + (row.rating || 0), 0);
            const totalBSR = categoryRows.reduce((sum, row) => sum + (row.subCategoryBSR || 0), 0);
            stats.avgRating = stats.count > 0 ? Number((totalRating / stats.count).toFixed(2)) : 0;
            stats.avgBSR = stats.count > 0 ? Number((totalBSR / stats.count).toFixed(0)) : 0;
        });

        return Object.values(categoryStats).sort((a, b) => b.totalRevenue - a.totalRevenue);
    }

    /**
     * 获取品牌列表
     * @returns {Array} 品牌数组
     */
    getBrands() {
        const brandSet = new Set();
        this.processedData.forEach(row => {
            if (row.brand && row.brand.trim() !== '') {
                brandSet.add(row.brand);
            }
        });
        return Array.from(brandSet).sort();
    }

    /**
     * 获取品牌统计
     * @returns {Array} 品牌统计数据
     */
    getBrandStats() {
        const brandStats = {};
        
        console.log('🔍 开始分析品牌数据...');
        console.log('📊 总数据行数:', this.processedData.length);
        
        // 检查品牌数据
        const brandData = this.processedData.map(row => ({
            productName: row.productName,
            brand: row.brand,
            brandType: typeof row.brand,
            brandLength: row.brand ? row.brand.length : 0
        }));
        
        console.log('🏷️ 品牌数据样本:', brandData.slice(0, 5));
        
        // 统计空品牌数量
        const emptyBrands = brandData.filter(item => !item.brand || item.brand.trim() === '');
        console.log('❌ 空品牌数量:', emptyBrands.length);
        console.log('❌ 空品牌产品:', emptyBrands.slice(0, 3));
        
        this.processedData.forEach(row => {
            // 跳过空品牌
            if (!row.brand || row.brand.trim() === '') {
                return;
            }
            
            if (!brandStats[row.brand]) {
                brandStats[row.brand] = {
                    name: row.brand,
                    count: 0,
                    totalRevenue: 0,
                    avgRating: 0,
                    totalReviews: 0,
                    avgBSR: 0
                };
            }
            
            brandStats[row.brand].count++;
            brandStats[row.brand].totalRevenue += row.monthlyRevenue || 0;
            brandStats[row.brand].totalReviews += row.reviewCount || 0;
        });

        // 计算平均评分和BSR
        Object.keys(brandStats).forEach(brand => {
            const stats = brandStats[brand];
            const brandRows = this.processedData.filter(row => row.brand === brand);
            const totalRating = brandRows.reduce((sum, row) => sum + (row.rating || 0), 0);
            const totalBSR = brandRows.reduce((sum, row) => sum + (row.subCategoryBSR || 0), 0);
            stats.avgRating = stats.count > 0 ? Number((totalRating / stats.count).toFixed(2)) : 0;
            stats.avgBSR = stats.count > 0 ? Number((totalBSR / stats.count).toFixed(0)) : 0;
        });

        return Object.values(brandStats).sort((a, b) => b.totalRevenue - a.totalRevenue);
    }

    /**
     * 获取热销产品排行
     * @param {number} limit - 限制数量
     * @returns {Array} 热销产品排行
     */
    getTopProducts(limit = 10) {
        return this.processedData
            .sort((a, b) => (b.monthlyRevenue || 0) - (a.monthlyRevenue || 0))
            .slice(0, limit)
            .map((row, index) => ({
                ...row,
                rank: index + 1
            }));
    }

    /**
     * 获取BSR排名最好的产品
     * @param {number} limit - 限制数量
     * @returns {Array} BSR排名产品
     */
    getTopBSRProducts(limit = 10) {
        return this.processedData
            .filter(row => row.subCategoryBSR && row.subCategoryBSR > 0)
            .sort((a, b) => (a.subCategoryBSR || 999999) - (b.subCategoryBSR || 999999))
            .slice(0, limit)
            .map((row, index) => ({
                ...row,
                rank: index + 1
            }));
    }

    /**
     * 导出数据
     * @param {Array} data - 要导出的数据
     * @param {string} format - 导出格式 ('csv', 'json')
     * @returns {string} 导出的数据
     */
    exportData(data = this.processedData, format = 'csv') {
        switch (format) {
            case 'csv':
                return this.exportToCSV(data);
            case 'json':
                return JSON.stringify(data, null, 2);
            default:
                throw new Error('不支持的导出格式');
        }
    }

    /**
     * 导出为CSV格式
     * @param {Array} data - 数据
     * @returns {string} CSV字符串
     */
    exportToCSV(data) {
        if (data.length === 0) return '';

        const headers = [
            '产品名称', '品牌', '类别', '月销售额', '月销量', '评分', '评论数', 
            '小类BSR', '价格', '转化率', '销售排名'
        ];

        const csvRows = [headers.join(',')];

        data.forEach(row => {
            const values = [
                `"${row.productName || ''}"`,
                `"${row.brand || ''}"`,
                `"${row.mainCategory || row.category || ''}"`,
                row.monthlyRevenue || 0,
                row.monthlySales || 0,
                row.rating || 0,
                row.reviewCount || 0,
                row.subCategoryBSR || 0,
                row.price || 0,
                row.conversionRate || 0,
                row.salesRank || 0
            ];
            csvRows.push(values.join(','));
        });

        return csvRows.join('\n');
    }
}

// 导出数据处理类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DataProcessor;
} 