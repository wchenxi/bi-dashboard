// AI服务模块
class AIService {
    constructor() {
        this.apiKey = CONFIG.API.AI_SERVICE.API_KEY;
        this.baseUrl = CONFIG.API.AI_SERVICE.BASE_URL;
        this.model = CONFIG.API.AI_SERVICE.MODEL;
        this.maxTokens = CONFIG.API.AI_SERVICE.MAX_TOKENS;
    }

    /**
     * 设置API密钥
     * @param {string} apiKey - API密钥
     */
    setApiKey(apiKey) {
        this.apiKey = apiKey;
        CONFIG.API.AI_SERVICE.API_KEY = apiKey;
        Utils.storage.set('ai_api_key', apiKey);
    }

    /**
     * 获取API密钥
     * @returns {string} API密钥
     */
    getApiKey() {
        if (!this.apiKey) {
            this.apiKey = Utils.storage.get('ai_api_key', '');
        }
        return this.apiKey;
    }

    /**
     * 检查API密钥是否配置
     * @returns {boolean} 是否已配置
     */
    isApiKeyConfigured() {
        return !!this.getApiKey();
    }

    /**
     * 分析销售数据
     * @param {Array} data - 销售数据
     * @param {string} analysisType - 分析类型
     * @returns {Promise<Object>} 分析结果
     */
    async analyzeSalesData(data, analysisType = 'general') {
        if (!this.isApiKeyConfigured()) {
            throw new Error(CONFIG.ERROR_MESSAGES.API_KEY_MISSING);
        }

        try {
            const prompt = this.generateAnalysisPrompt(data, analysisType);
            const response = await this.callAIAPI(prompt);
            return this.parseAnalysisResponse(response, analysisType);
        } catch (error) {
            console.error('AI分析错误:', error);
            throw new Error(CONFIG.ERROR_MESSAGES.AI_ANALYSIS_FAILED);
        }
    }

    /**
     * 生成分析提示词
     * @param {Array} data - 数据
     * @param {string} analysisType - 分析类型
     * @returns {string} 提示词
     */
    generateAnalysisPrompt(data, analysisType) {
        const summary = this.generateDataSummary(data);
        
        const prompts = {
            general: `请分析以下亚马逊电商数据并提供洞察：

数据摘要：
${summary}

请提供：
1. 关键发现和趋势
2. 表现最佳的产品类别
3. 改进建议
4. 市场机会分析

请用中文回答，格式要清晰易读。`,

            sales: `请分析以下销售数据趋势：

${summary}

请重点关注：
1. 销售趋势分析
2. 季节性模式
3. 增长机会
4. 销售预测

请用中文回答，提供具体的数据支持。`,

            competition: `请进行竞争分析：

${summary}

请分析：
1. 竞争格局
2. 市场份额
3. 竞争优势
4. 竞争策略建议

请用中文回答，提供实用的竞争洞察。`,

            optimization: `请提供优化建议：

${summary}

请提供：
1. 产品优化建议
2. 定价策略
3. 营销优化
4. 运营改进

请用中文回答，提供可执行的建议。`,

            prediction: `请进行销售预测：

${summary}

请预测：
1. 未来30天销售趋势
2. 季节性影响
3. 增长潜力
4. 风险因素

请用中文回答，提供量化的预测数据。`
        };

        return prompts[analysisType] || prompts.general;
    }

    /**
     * 生成数据摘要
     * @param {Array} data - 数据
     * @returns {string} 数据摘要
     */
    generateDataSummary(data) {
        if (!data || data.length === 0) {
            return '暂无数据';
        }

        const totalProducts = data.length;
        const totalSales = data.reduce((sum, item) => sum + (item.sales || 0), 0);
        const avgRating = data.reduce((sum, item) => sum + (item.rating || 0), 0) / totalProducts;
        const totalReviews = data.reduce((sum, item) => sum + (item.reviews || 0), 0);
        const avgPrice = data.reduce((sum, item) => sum + (item.price || 0), 0) / totalProducts;

        // 类别统计
        const categoryStats = Utils.groupBy(data, 'category');
        const topCategories = Object.entries(categoryStats)
            .map(([category, items]) => ({
                category,
                sales: items.reduce((sum, item) => sum + (item.sales || 0), 0),
                count: items.length
            }))
            .sort((a, b) => b.sales - a.sales)
            .slice(0, 5);

        // 热销产品
        const topProducts = data
            .sort((a, b) => (b.sales || 0) - (a.sales || 0))
            .slice(0, 5);

        return `
总产品数：${totalProducts}
总销售额：$${Utils.formatNumber(totalSales)}
平均评分：${avgRating.toFixed(2)}
总评论数：${Utils.formatNumber(totalReviews)}
平均价格：$${Utils.formatNumber(avgPrice, 2)}

热门类别：
${topCategories.map((cat, index) => `${index + 1}. ${cat.category}: $${Utils.formatNumber(cat.sales)} (${cat.count}个产品)`).join('\n')}

热销产品：
${topProducts.map((product, index) => `${index + 1}. ${product.productName}: $${Utils.formatNumber(product.sales)}`).join('\n')}
        `.trim();
    }

    /**
     * 调用AI API
     * @param {string} prompt - 提示词
     * @returns {Promise<Object>} API响应
     */
    async callAIAPI(prompt) {
        const requestBody = {
            model: this.model,
            messages: [
                {
                    role: "system",
                    content: "你是一个专业的电商数据分析师，擅长分析亚马逊电商数据并提供有价值的洞察和建议。"
                },
                {
                    role: "user",
                    content: prompt
                }
            ],
            max_tokens: this.maxTokens,
            temperature: 0.7
        };

        const response = await fetch(this.baseUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.getApiKey()}`
            },
            body: JSON.stringify(requestBody)
        });

        if (!response.ok) {
            throw new Error(`API请求失败: ${response.status} ${response.statusText}`);
        }

        const result = await response.json();
        
        if (result.error) {
            throw new Error(`AI服务错误: ${result.error.message}`);
        }

        return result;
    }

    /**
     * 解析AI分析响应
     * @param {Object} response - API响应
     * @param {string} analysisType - 分析类型
     * @returns {Object} 解析后的结果
     */
    parseAnalysisResponse(response, analysisType) {
        const content = response.choices?.[0]?.message?.content;
        if (!content) {
            throw new Error('AI响应格式错误');
        }

        // 解析响应内容
        const insights = this.extractInsights(content);
        const recommendations = this.extractRecommendations(content);
        const metrics = this.extractMetrics(content);

        return {
            type: analysisType,
            content: content,
            insights: insights,
            recommendations: recommendations,
            metrics: metrics,
            timestamp: new Date().toISOString()
        };
    }

    /**
     * 提取洞察信息
     * @param {string} content - AI响应内容
     * @returns {Array} 洞察列表
     */
    extractInsights(content) {
        const insights = [];
        
        // 提取关键洞察
        const insightPatterns = [
            /(?:发现|洞察|趋势|表现)[：:]\s*(.+?)(?=\n|$)/g,
            /(?:主要|重要|关键)[：:]\s*(.+?)(?=\n|$)/g,
            /(?:分析|观察)[：:]\s*(.+?)(?=\n|$)/g
        ];

        insightPatterns.forEach(pattern => {
            let match;
            while ((match = pattern.exec(content)) !== null) {
                insights.push({
                    type: 'insight',
                    content: match[1].trim(),
                    icon: 'lightbulb'
                });
            }
        });

        return insights.slice(0, 5); // 限制数量
    }

    /**
     * 提取建议信息
     * @param {string} content - AI响应内容
     * @returns {Array} 建议列表
     */
    extractRecommendations(content) {
        const recommendations = [];
        
        // 提取建议
        const recommendationPatterns = [
            /(?:建议|推荐|优化)[：:]\s*(.+?)(?=\n|$)/g,
            /(?:应该|可以|建议)[：:]\s*(.+?)(?=\n|$)/g,
            /(?:改进|提升|优化)[：:]\s*(.+?)(?=\n|$)/g
        ];

        recommendationPatterns.forEach(pattern => {
            let match;
            while ((match = pattern.exec(content)) !== null) {
                recommendations.push({
                    type: 'recommendation',
                    content: match[1].trim(),
                    icon: 'check-circle'
                });
            }
        });

        return recommendations.slice(0, 5); // 限制数量
    }

    /**
     * 提取指标信息
     * @param {string} content - AI响应内容
     * @returns {Array} 指标列表
     */
    extractMetrics(content) {
        const metrics = [];
        
        // 提取数字指标
        const metricPatterns = [
            /(\d+(?:\.\d+)?)\s*(?:%|percent|百分比)/g,
            /(\d+(?:\.\d+)?)\s*(?:美元|\$|USD)/g,
            /(\d+(?:\.\d+)?)\s*(?:个|件|次)/g
        ];

        metricPatterns.forEach(pattern => {
            let match;
            while ((match = pattern.exec(content)) !== null) {
                metrics.push({
                    type: 'metric',
                    value: parseFloat(match[1]),
                    unit: match[0].replace(match[1], '').trim(),
                    icon: 'chart-line'
                });
            }
        });

        return metrics.slice(0, 3); // 限制数量
    }

    /**
     * 生成快速洞察
     * @param {Array} data - 数据
     * @returns {Array} 快速洞察列表
     */
    generateQuickInsights(data) {
        if (!data || data.length === 0) {
            return [];
        }

        const insights = [];
        const summary = this.generateDataSummary(data);

        // 销售额洞察
        const totalSales = data.reduce((sum, item) => sum + (item.sales || 0), 0);
        const avgSales = totalSales / data.length;
        const topSales = Math.max(...data.map(item => item.sales || 0));
        
        if (topSales > avgSales * 2) {
            insights.push({
                type: 'insight',
                title: '销售表现差异显著',
                content: `最高销售额产品($${Utils.formatNumber(topSales)})是平均销售额的${(topSales/avgSales).toFixed(1)}倍`,
                icon: 'trending-up',
                color: 'success'
            });
        }

        // 评分洞察
        const avgRating = data.reduce((sum, item) => sum + (item.rating || 0), 0) / data.length;
        if (avgRating >= 4.0) {
            insights.push({
                type: 'insight',
                title: '产品评分优秀',
                content: `平均评分${avgRating.toFixed(1)}分，产品质量表现良好`,
                icon: 'star',
                color: 'success'
            });
        } else if (avgRating < 3.0) {
            insights.push({
                type: 'insight',
                title: '产品评分需改进',
                content: `平均评分${avgRating.toFixed(1)}分，建议优化产品质量`,
                icon: 'exclamation-triangle',
                color: 'warning'
            });
        }

        // 类别洞察
        const categoryStats = Utils.groupBy(data, 'category');
        const categorySales = Object.entries(categoryStats).map(([category, items]) => ({
            category,
            sales: items.reduce((sum, item) => sum + (item.sales || 0), 0)
        })).sort((a, b) => b.sales - a.sales);

        if (categorySales.length > 0) {
            const topCategory = categorySales[0];
            const topCategoryPercentage = (topCategory.sales / totalSales * 100).toFixed(1);
            
            insights.push({
                type: 'insight',
                title: '类别集中度高',
                content: `${topCategory.category}类别占总销售额的${topCategoryPercentage}%`,
                icon: 'chart-pie',
                color: 'info'
            });
        }

        // 价格洞察
        const prices = data.map(item => item.price || 0).filter(price => price > 0);
        if (prices.length > 0) {
            const avgPrice = prices.reduce((sum, price) => sum + price, 0) / prices.length;
            const priceRange = Math.max(...prices) - Math.min(...prices);
            
            if (priceRange > avgPrice * 2) {
                insights.push({
                    type: 'insight',
                    title: '价格区间较大',
                    content: `产品价格差异显著，建议优化定价策略`,
                    icon: 'dollar-sign',
                    color: 'warning'
                });
            }
        }

        return insights.slice(0, 4); // 限制数量
    }

    /**
     * 保存分析结果
     * @param {Object} result - 分析结果
     */
    saveAnalysisResult(result) {
        const savedResults = Utils.storage.get('ai_analysis_results', []);
        savedResults.unshift({
            ...result,
            id: Utils.generateId(),
            savedAt: new Date().toISOString()
        });
        
        // 只保留最近10次分析结果
        if (savedResults.length > 10) {
            savedResults.splice(10);
        }
        
        Utils.storage.set('ai_analysis_results', savedResults);
    }

    /**
     * 获取保存的分析结果
     * @returns {Array} 分析结果列表
     */
    getSavedAnalysisResults() {
        return Utils.storage.get('ai_analysis_results', []);
    }

    /**
     * 删除分析结果
     * @param {string} resultId - 结果ID
     */
    deleteAnalysisResult(resultId) {
        const savedResults = Utils.storage.get('ai_analysis_results', []);
        const filteredResults = savedResults.filter(result => result.id !== resultId);
        Utils.storage.set('ai_analysis_results', filteredResults);
    }

    /**
     * 清除所有分析结果
     */
    clearAllAnalysisResults() {
        Utils.storage.remove('ai_analysis_results');
    }
}

// 导出AI服务类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AIService;
} 