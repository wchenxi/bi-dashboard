// 仪表盘主模块
class Dashboard {
    constructor() {
        this.dataProcessor = new DataProcessor();
        this.chartManager = new ChartManager();
        this.aiService = new AIService();
        this.currentData = [];
        this.currentFilters = {};
        this.currentPage = 1;
        this.pageSize = CONFIG.TABLE.PAGE_SIZE;
        
        this.init();
    }

    /**
     * 初始化仪表盘
     */
    init() {
        try {
            this.bindEvents();
            this.setupDatePickers();
            this.loadDefaultExcelFile(); // 自动加载默认Excel文件
            this.updateDashboard();
        } catch (error) {
            console.error('仪表盘初始化失败:', error);
            Utils.showNotification('仪表盘初始化失败，请刷新页面', 'error');
        }
    }

    /**
     * 绑定事件监听器
     */
    bindEvents() {
        // 侧边栏导航
        document.querySelectorAll('.sidebar-nav a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleNavigation(e.target.closest('a').getAttribute('href').substring(1));
            });
        });

        // 菜单切换
        const menuToggle = document.getElementById('menuToggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => {
                document.querySelector('.sidebar').classList.toggle('show');
            });
        }

        // 调试按钮
        const debugBtn = document.getElementById('debugBtn');
        if (debugBtn) {
            debugBtn.addEventListener('click', () => {
                this.debugBrandData();
            });
        }

        // 刷新按钮
        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', Utils.debounce(() => {
                this.refreshData();
            }, 1000));
        }

        // 日期选择器
        const startDate = document.getElementById('startDate');
        const endDate = document.getElementById('endDate');
        if (startDate && endDate) {
            startDate.addEventListener('change', () => this.handleDateChange());
            endDate.addEventListener('change', () => this.handleDateChange());
        }

        // 销售图表周期选择
        const salesChartPeriod = document.getElementById('salesChartPeriod');
        if (salesChartPeriod) {
            salesChartPeriod.addEventListener('change', () => {
                this.updateSalesChart();
            });
        }

        // 搜索输入
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', Utils.debounce(() => {
                this.handleSearch();
            }, 300));
        }

        // 排序选择
        const sortBy = document.getElementById('sortBy');
        if (sortBy) {
            sortBy.addEventListener('change', () => {
                this.handleSort();
            });
        }

        // AI分析按钮
        const startAnalysisBtn = document.getElementById('startAnalysis');
        if (startAnalysisBtn) {
            startAnalysisBtn.addEventListener('click', () => {
                this.startAIAnalysis();
            });
        }

        // AI模态框关闭
        const closeAiModal = document.getElementById('closeAiModal');
        if (closeAiModal) {
            closeAiModal.addEventListener('click', () => {
                this.closeAIModal();
            });
        }

        // 模态框背景点击关闭
        const aiModal = document.getElementById('aiModal');
        if (aiModal) {
            aiModal.addEventListener('click', (e) => {
                if (e.target === aiModal) {
                    this.closeAIModal();
                }
            });
        }
    }

    /**
     * 设置日期选择器
     */
    setupDatePickers() {
        const startDate = document.getElementById('startDate');
        const endDate = document.getElementById('endDate');
        
        if (startDate && endDate) {
            const today = new Date();
            const thirtyDaysAgo = new Date(today.getTime() - (30 * 24 * 60 * 60 * 1000));
            
            startDate.value = Utils.formatDate(thirtyDaysAgo, 'YYYY-MM-DD');
            endDate.value = Utils.formatDate(today, 'YYYY-MM-DD');
        }
    }

    /**
     * 加载默认Excel文件
     */
    async loadDefaultExcelFile() {
        try {
            Utils.showLoading('正在加载Excel文件...');
            
            // 检查是否通过HTTP服务器访问
            const isHttpServer = window.location.protocol === 'http:' || window.location.protocol === 'https:';
            console.log('当前协议:', window.location.protocol);
            console.log('当前URL:', window.location.href);
            console.log('是否HTTP服务器访问:', isHttpServer);
            
            if (!isHttpServer) {
                // 如果不是通过HTTP服务器访问，显示错误提示
                Utils.showLoading(false);
                Utils.showNotification('请通过HTTP服务器访问页面以加载Excel文件', 'error');
                return;
            }
            
            console.log('开始请求Excel文件...');
            
            // 使用fetch加载Excel文件 - 支持相对路径和绝对路径
            let excelPath = 'BSR(Cradles(Current))-100-US.xlsx';
            
            // 如果是部署环境，尝试不同的路径
            if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
                // 部署环境，尝试多种路径
                const possiblePaths = [
                    './BSR(Cradles(Current))-100-US.xlsx',
                    '/BSR(Cradles(Current))-100-US.xlsx',
                    './data/BSR(Cradles(Current))-100-US.xlsx',
                    '/data/BSR(Cradles(Current))-100-US.xlsx'
                ];
                
                for (const path of possiblePaths) {
                    try {
                        const testResponse = await fetch(path, { method: 'HEAD' });
                        if (testResponse.ok) {
                            excelPath = path;
                            console.log('找到Excel文件路径:', excelPath);
                            break;
                        }
                    } catch (e) {
                        console.log('路径测试失败:', path);
                    }
                }
            }
            
            // 通过HTTP服务器请求Excel文件
            const response = await fetch(excelPath);
            
            console.log('Excel文件响应状态:', response.status);
            console.log('Excel文件响应头:', response.headers);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const arrayBuffer = await response.arrayBuffer();
            const data = new Uint8Array(arrayBuffer);
            
            console.log('Excel文件大小:', data.length, '字节');
            
            // 解析Excel文件
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
            
            console.log('Excel文件读取成功:', jsonData.length, '行数据');
            console.log('第一行数据（表头）:', jsonData[0]);
            console.log('第二行数据（示例）:', jsonData[1]);
            
            // 处理Excel数据
            this.dataProcessor.processExcelData(jsonData).then(result => {
                console.log('数据处理成功:', result);
                this.currentData = result.data;
                // 重置页码到第一页
                this.currentPage = 1;
                this.updateDashboard();
                Utils.showLoading(false);
                Utils.showNotification('Excel文件加载成功', 'success');
            }).catch(error => {
                console.error('数据处理失败:', error);
                Utils.showLoading(false);
                Utils.showNotification('数据处理失败', 'error');
            });
            
        } catch (error) {
            console.error('加载默认Excel文件失败:', error);
            Utils.showLoading(false);
            Utils.showNotification('加载默认Excel文件失败，请确保文件存在', 'error');
        }
    }



    /**
     * 加载模拟数据（保留作为备用）
     */
    loadMockData() {
        try {
            Utils.showLoading('正在加载数据...');
            
            // 尝试从localStorage获取缓存的数据
            const cachedData = localStorage.getItem('dashboard_mock_data');
            let mockData;
            
            if (cachedData) {
                mockData = JSON.parse(cachedData);
                console.log('使用缓存的数据');
            } else {
                mockData = this.generateMockData();
                // 将数据缓存到localStorage
                localStorage.setItem('dashboard_mock_data', JSON.stringify(mockData));
                console.log('生成新的数据并缓存');
            }
            
            this.dataProcessor.processExcelData(mockData).then(result => {
                this.currentData = result.data;
                this.updateDashboard();
                Utils.showLoading(false);
            }).catch(error => {
                console.error('数据加载失败:', error);
                Utils.showLoading(false);
                Utils.showNotification(CONFIG.ERROR_MESSAGES.LOAD_DATA_FAILED, 'error');
            });
        } catch (error) {
            console.error('数据加载失败:', error);
            Utils.showLoading(false);
            Utils.showNotification('数据加载失败', 'error');
        }
    }

    /**
     * 生成模拟数据
     * @returns {Array} 模拟数据
     */
    generateMockData() {
        const categories = ['手机配件', '电脑配件', '家居用品', '运动器材', '数码产品'];
        const products = [
            '无线充电器', '手机壳', '数据线', '耳机', '充电宝',
            '键盘', '鼠标', '显示器', '音箱', '摄像头',
            '台灯', '水杯', '收纳盒', '抱枕', '地毯',
            '瑜伽垫', '哑铃', '跑步机', '篮球', '足球',
            '平板电脑', '智能手表', '蓝牙音箱', '摄像头', '路由器'
        ];

        const data = [['Product Name', 'Category', 'Sales', 'Rating', 'Reviews', 'BSR', 'Price', 'Date']];

        for (let i = 0; i < 100; i++) {
            const productName = products[Math.floor(Math.random() * products.length)];
            const category = categories[Math.floor(Math.random() * categories.length)];
            const sales = Math.floor(Math.random() * 10000) + 100;
            const rating = (Math.random() * 2 + 3).toFixed(1);
            const reviews = Math.floor(Math.random() * 1000) + 10;
            const bsr = Math.floor(Math.random() * 10000) + 1;
            const price = (Math.random() * 200 + 10).toFixed(2);
            const date = new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000);

            data.push([
                productName,
                category,
                sales,
                rating,
                reviews,
                bsr,
                price,
                Utils.formatDate(date, 'YYYY-MM-DD')
            ]);
        }

        return data;
    }

    /**
     * 更新仪表盘
     */
    updateDashboard() {
        try {
            this.updateMetrics();
            this.updateCharts();
            this.updateTable();
            this.updateAIInsights();
        } catch (error) {
            console.error('更新仪表盘失败:', error);
            Utils.showNotification('更新仪表盘失败', 'error');
        }
    }

    /**
     * 更新关键指标
     */
    updateMetrics() {
        if (this.currentData.length === 0) return;

        const summary = this.dataProcessor.generateSummary();
        
        // 更新总销售额
        const totalRevenueEl = document.getElementById('totalSales');
        if (totalRevenueEl) {
            totalRevenueEl.textContent = Utils.formatNumber(summary.totalRevenue, 'currency');
        }

        // 更新总销量
        const totalSalesEl = document.getElementById('totalOrders');
        if (totalSalesEl) {
            totalSalesEl.textContent = Utils.formatNumber(summary.totalSales);
        }

        // 更新产品数量
        const totalProductsEl = document.getElementById('avgRating');
        if (totalProductsEl) {
            totalProductsEl.textContent = Utils.formatNumber(summary.totalProducts);
        }

        // 更新平均BSR
        const avgBSREl = document.getElementById('conversionRate');
        if (avgBSREl) {
            avgBSREl.textContent = Utils.formatNumber(summary.avgBSR);
        }
    }

    /**
     * 更新图表
     */
    updateCharts() {
        try {
            // 更新类别分布图
            const categoryStats = this.dataProcessor.getCategoryStats();
            this.chartManager.initCategoryChart('categoryChart', categoryStats);

            // 更新品牌分布图
            const brandStats = this.dataProcessor.getBrandStats();
            console.log('📈 获取到的品牌统计:', brandStats);
            this.chartManager.initBrandChart('brandChart', brandStats);

            // 更新热销产品排行
            this.updateTopProducts();
        } catch (error) {
            console.error('更新图表失败:', error);
        }
    }

    /**
     * 更新热销产品排行
     */
    updateTopProducts() {
        const topProductsContainer = document.getElementById('topProducts');
        if (!topProductsContainer) return;

        const topProducts = this.dataProcessor.getTopProducts(10);
        
        topProductsContainer.innerHTML = topProducts.map(product => `
            <div class="ranking-item">
                <div class="ranking-number">${product.rank}</div>
                <div class="ranking-info">
                    <div class="ranking-title">${product.productName}</div>
                    <div class="ranking-meta">${product.brand || '未知品牌'} • ${Utils.formatNumber(product.reviewCount)} 评论</div>
                </div>
                <div class="ranking-value">$${Utils.formatNumber(product.monthlyRevenue)}</div>
            </div>
        `).join('');
    }

    /**
     * 格式化货币
     * @param {number} value - 数值
     * @returns {string} 格式化后的货币字符串
     */
    formatCurrency(value) {
        if (!value || isNaN(value)) return '$0';
        return '$' + Utils.formatNumber(value);
    }

    /**
     * 格式化数字
     * @param {number} value - 数值
     * @returns {string} 格式化后的数字字符串
     */
    formatNumber(value) {
        if (!value || isNaN(value)) return '0';
        return Utils.formatNumber(value);
    }

    /**
     * 更新表格信息
     * @param {number} totalRows - 总行数
     */
    updateTableInfo(totalRows) {
        const tableInfo = document.getElementById('tableInfo');
        if (tableInfo) {
            tableInfo.textContent = `共 ${totalRows} 条记录`;
        }
    }

    /**
     * 更新数据表格
     */
    updateTable(data = null) {
        const tableBody = document.getElementById('tableBody');
        if (!tableBody) return;

        // 如果没有传入数据，则使用过滤后的数据
        if (!data) {
            data = this.dataProcessor.filterData(this.currentFilters);
        }

        // 计算分页数据
        const totalItems = data.length;
        const totalPages = Math.ceil(totalItems / this.pageSize);
        
        // 确保当前页码在有效范围内
        if (this.currentPage > totalPages) {
            this.currentPage = totalPages || 1;
        }
        
        // 计算当前页的数据范围
        const startIndex = (this.currentPage - 1) * this.pageSize;
        const endIndex = Math.min(startIndex + this.pageSize, totalItems);
        const currentPageData = data.slice(startIndex, endIndex);

        tableBody.innerHTML = '';

        currentPageData.forEach((row, index) => {
            const tr = document.createElement('tr');
            
            // 产品名称单元格（带折叠功能）
            const productNameCell = document.createElement('td');
            productNameCell.className = 'product-name-cell';
            
            const productNameContent = document.createElement('div');
            productNameContent.className = 'product-name-content collapsed';
            
            const fullName = row.productName || '未知产品';
            const shortName = fullName.length > 50 ? fullName.substring(0, 50) + '...' : fullName;
            
            productNameContent.textContent = shortName;
            productNameContent.title = fullName;
            
            const expandToggle = document.createElement('button');
            expandToggle.className = 'expand-toggle';
            expandToggle.innerHTML = '▼';
            expandToggle.title = '展开/折叠';
            
            // 只有产品名称超过50个字符时才显示展开按钮
            if (fullName.length <= 50) {
                expandToggle.style.display = 'none';
            }
            
            // 展开/折叠事件
            expandToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                const isExpanded = productNameContent.classList.contains('expanded');
                
                if (isExpanded) {
                    productNameContent.classList.remove('expanded');
                    productNameContent.classList.add('collapsed');
                    productNameContent.textContent = shortName;
                    expandToggle.classList.remove('expanded');
                    expandToggle.innerHTML = '▼';
                } else {
                    productNameContent.classList.remove('collapsed');
                    productNameContent.classList.add('expanded');
                    productNameContent.textContent = fullName;
                    expandToggle.classList.add('expanded');
                    expandToggle.innerHTML = '▲';
                }
            });
            
            productNameCell.appendChild(productNameContent);
            productNameCell.appendChild(expandToggle);
            
            // 计算实际的行号（考虑分页）
            const actualRowNumber = startIndex + index + 1;
            
            tr.innerHTML = `
                <td>${actualRowNumber}</td>
                <td>${row.brand || '未知品牌'}</td>
                <td>${row.mainCategory || row.category || '未知类别'}</td>
                <td>${this.formatCurrency(row.monthlyRevenue)}</td>
                <td>${this.formatNumber(row.monthlySales)}</td>
                <td>${this.formatNumber(row.reviewCount)}</td>
                <td>${this.formatNumber(row.subCategoryBSR)}</td>
                <td>${this.formatCurrency(row.price)}</td>
            `;
            
            // 替换产品名称单元格
            tr.replaceChild(productNameCell, tr.children[0]);
            
            tableBody.appendChild(tr);
        });

        // 更新表格信息
        this.updateTableInfo(totalItems);
        
        // 更新分页控件
        this.updatePagination(totalItems);
    }

    /**
     * 更新分页控件
     * @param {number} totalItems - 总项目数
     */
    updatePagination(totalItems) {
        const paginationContainer = document.getElementById('pagination');
        if (!paginationContainer) return;

        const totalPages = Math.ceil(totalItems / this.pageSize);
        
        if (totalPages <= 1) {
            paginationContainer.innerHTML = '';
            return;
        }

        const paginationInfo = `
            <div class="pagination-info">
                显示第 ${(this.currentPage - 1) * this.pageSize + 1} - ${Math.min(this.currentPage * this.pageSize, totalItems)} 条，共 ${totalItems} 条
            </div>
        `;

        const paginationControls = `
            <div class="pagination-controls">
                <button class="pagination-btn" ${this.currentPage === 1 ? 'disabled' : ''} onclick="dashboard.goToPage(${this.currentPage - 1})">
                    <i class="fas fa-chevron-left"></i>
                </button>
                
                ${this.generatePageNumbers(totalPages)}
                
                <button class="pagination-btn" ${this.currentPage === totalPages ? 'disabled' : ''} onclick="dashboard.goToPage(${this.currentPage + 1})">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        `;

        paginationContainer.innerHTML = paginationInfo + paginationControls;
    }

    /**
     * 生成页码按钮
     * @param {number} totalPages - 总页数
     * @returns {string} 页码HTML
     */
    generatePageNumbers(totalPages) {
        const pages = [];
        const maxVisiblePages = 5;
        
        if (totalPages <= maxVisiblePages) {
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i);
            }
        } else {
            if (this.currentPage <= 3) {
                for (let i = 1; i <= 4; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            } else if (this.currentPage >= totalPages - 2) {
                pages.push(1);
                pages.push('...');
                for (let i = totalPages - 3; i <= totalPages; i++) {
                    pages.push(i);
                }
            } else {
                pages.push(1);
                pages.push('...');
                for (let i = this.currentPage - 1; i <= this.currentPage + 1; i++) {
                    pages.push(i);
                }
                pages.push('...');
                pages.push(totalPages);
            }
        }

        return pages.map(page => {
            if (page === '...') {
                return '<span class="pagination-ellipsis">...</span>';
            }
            return `
                <button class="pagination-btn ${page === this.currentPage ? 'active' : ''}" onclick="dashboard.goToPage(${page})">
                    ${page}
                </button>
            `;
        }).join('');
    }

    /**
     * 更新AI洞察
     */
    updateAIInsights() {
        const aiInsightsContainer = document.getElementById('aiInsights');
        if (!aiInsightsContainer) return;

        const insights = this.aiService.generateQuickInsights(this.currentData);
        
        if (insights.length === 0) {
            aiInsightsContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-robot"></i>
                    <h3>暂无AI洞察</h3>
                    <p>点击"AI分析"按钮开始深度分析</p>
                </div>
            `;
            return;
        }

        aiInsightsContainer.innerHTML = insights.map(insight => `
            <div class="insight-item">
                <div class="insight-header">
                    <div class="insight-icon">
                        <i class="fas fa-${insight.icon}"></i>
                    </div>
                    <div class="insight-title">${insight.title}</div>
                </div>
                <div class="insight-content">${insight.content}</div>
                <span class="insight-tag">AI洞察</span>
            </div>
        `).join('');
    }

    /**
     * 处理导航
     * @param {string} section - 导航部分
     */
    handleNavigation(section) {
        // 更新活动状态
        document.querySelectorAll('.sidebar-nav li').forEach(li => li.classList.remove('active'));
        document.querySelector(`[href="#${section}"]`).closest('li').classList.add('active');

        // 隐藏所有内容区域
        document.querySelectorAll('.content-section').forEach(content => {
            content.style.display = 'none';
        });

        // 显示对应的内容区域
        const targetSection = document.getElementById(section);
        if (targetSection) {
            targetSection.style.display = 'block';
        }

        // 根据不同的section执行相应的逻辑
        switch (section) {
            case 'dashboard':
                // 仪表盘页面 - 显示所有内容
                this.updateDashboard();
                break;
            case 'sales':
                // 销售分析页面
                this.showSalesAnalysis();
                break;
            case 'products':
                // 产品分析页面
                this.showProductAnalysis();
                break;
            case 'ai-analysis':
                // AI分析页面
                this.showAIAnalysis();
                break;
            case 'settings':
                // 设置页面
                this.showSettings();
                break;
            default:
                console.log('未知的导航部分:', section);
        }

        console.log('导航到:', section);
    }

    /**
     * 处理日期变化
     */
    handleDateChange() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        
        if (startDate && endDate) {
            this.currentFilters.startDate = startDate;
            this.currentFilters.endDate = endDate;
            this.currentPage = 1;
            this.updateTable();
        }
    }

    /**
     * 处理搜索
     */
    handleSearch() {
        const searchTerm = document.getElementById('searchInput').value;
        this.currentFilters.search = searchTerm;
        this.currentPage = 1;
        this.updateTable();
    }

    /**
     * 处理排序
     */
    handleSort() {
        const sortBy = document.getElementById('sortBy').value;
        // 如果选择的是空值，则清除排序
        if (sortBy === '') {
            delete this.currentFilters.sortBy;
        } else {
            this.currentFilters.sortBy = sortBy;
        }
        this.currentPage = 1;
        this.updateTable();
    }

    /**
     * 更新销售图表
     */
    updateSalesChart() {
        const period = document.getElementById('salesChartPeriod').value;
        const salesTrendData = this.dataProcessor.getSalesTrend(parseInt(period));
        this.chartManager.updateSalesChart(salesTrendData);
    }

    /**
     * 跳转到指定页面
     * @param {number} page - 页码
     */
    goToPage(page) {
        const totalItems = this.dataProcessor.processedData.length;
        const totalPages = Math.ceil(totalItems / this.pageSize);
        
        // 确保页码在有效范围内
        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;
        
        this.currentPage = page;
        this.updateTable();
    }

    /**
     * 刷新数据
     */
    refreshData() {
        // 重新加载默认Excel文件
        this.loadDefaultExcelFile();
        Utils.showNotification('正在重新加载数据', 'info');
    }

    /**
     * 生成新数据（清除缓存并生成新的随机数据）
     */
    generateNewData() {
        Utils.showLoading(true, '正在生成新数据...');
        
        setTimeout(() => {
            // 清除缓存的数据，强制生成新数据
            localStorage.removeItem('dashboard_mock_data');
            this.loadMockData();
            Utils.showLoading(false);
            Utils.showNotification('新数据生成成功', 'success');
        }, 1000);
    }

    /**
     * 开始AI分析
     */
    async startAIAnalysis() {
        const dimension = document.getElementById('analysisDimension').value;
        const scope = document.getElementById('analysisScope').value;

        if (!this.aiService.isApiKeyConfigured()) {
            Utils.showNotification('请先在设置中配置AI API密钥', 'warning');
            return;
        }

        Utils.showLoading(true, '正在进行AI分析...');

        try {
            const result = await this.aiService.analyzeSalesData(this.currentData, dimension);
            this.displayAIAnalysisResult(result);
            this.aiService.saveAnalysisResult(result);
            Utils.showNotification('AI分析完成', 'success');
        } catch (error) {
            console.error('AI分析失败:', error);
            Utils.showNotification(error.message, 'error');
        } finally {
            Utils.showLoading(false);
        }
    }

    /**
     * 显示AI分析结果
     * @param {Object} result - 分析结果
     */
    displayAIAnalysisResult(result) {
        const aiResultsContainer = document.getElementById('aiResults');
        if (!aiResultsContainer) return;

        aiResultsContainer.innerHTML = `
            <div class="ai-result-item">
                <div class="ai-result-title">
                    <i class="fas fa-robot"></i>
                    AI分析结果
                </div>
                <div class="ai-result-content">${result.content}</div>
                ${result.metrics.length > 0 ? `
                    <div class="ai-result-metrics">
                        ${result.metrics.map(metric => `
                            <span class="ai-metric">${metric.value}${metric.unit}</span>
                        `).join('')}
                    </div>
                ` : ''}
            </div>
        `;

        this.showAIModal();
    }

    /**
     * 显示AI模态框
     */
    showAIModal() {
        const modal = document.getElementById('aiModal');
        if (modal) {
            modal.classList.add('show');
        }
    }

    /**
     * 关闭AI模态框
     */
    closeAIModal() {
        const modal = document.getElementById('aiModal');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    /**
     * 查看产品详情
     * @param {string} productId - 产品ID
     */
    viewProduct(productId) {
        const product = this.currentData.find(item => item.id === productId);
        if (product) {
            Utils.showNotification(`查看产品: ${product.productName}`, 'info');
            // 这里可以添加产品详情弹窗逻辑
        }
    }

    /**
     * 分析产品
     * @param {string} productId - 产品ID
     */
    analyzeProduct(productId) {
        const product = this.currentData.find(item => item.id === productId);
        if (product) {
            Utils.showNotification(`开始分析产品: ${product.productName}`, 'info');
            // 这里可以添加单个产品的AI分析逻辑
        }
    }

    /**
     * 调试品牌数据
     */
    debugBrandData() {
        console.log('🔍 开始调试品牌数据...');
        
        if (!this.dataProcessor || !this.dataProcessor.processedData) {
            console.log('❌ 没有处理过的数据');
            return;
        }
        
        console.log('📊 总数据行数:', this.dataProcessor.processedData.length);
        
        // 检查前10行的品牌数据
        const sampleData = this.dataProcessor.processedData.slice(0, 10);
        sampleData.forEach((row, index) => {
            console.log(`📝 行${index + 1}:`, {
                productName: row.productName,
                brand: row.brand,
                brandType: typeof row.brand,
                brandLength: row.brand ? row.brand.length : 0,
                isEmpty: !row.brand || row.brand.trim() === ''
            });
        });
        
        // 获取品牌统计
        const brandStats = this.dataProcessor.getBrandStats();
        console.log('🏷️ 品牌统计:', brandStats);
        
        // 获取品牌列表
        const brands = this.dataProcessor.getBrands();
        console.log('📋 品牌列表:', brands);
        
        // 显示调试结果
        Utils.showNotification(`调试完成，查看控制台输出。品牌数量: ${brands.length}`, 'info');
    }

    /**
     * 导出数据
     * @param {string} format - 导出格式
     */
    exportData(format = 'csv') {
        try {
            const data = this.dataProcessor.exportData(this.currentData, format);
            const blob = new Blob([data], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            
            link.setAttribute('href', url);
            link.setAttribute('download', `amazon_data_${Utils.formatDate(new Date(), 'YYYY-MM-DD')}.${format}`);
            link.style.visibility = 'hidden';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            Utils.showNotification('数据导出成功', 'success');
        } catch (error) {
            console.error('导出失败:', error);
            Utils.showNotification('数据导出失败', 'error');
        }
    }

    /**
     * 显示销售分析页面
     */
    showSalesAnalysis() {
        console.log('显示销售分析页面');
        // 这里可以添加销售分析相关的逻辑
        Utils.showNotification('销售分析功能开发中...', 'info');
    }

    /**
     * 显示产品分析页面
     */
    showProductAnalysis() {
        console.log('显示产品分析页面');
        // 这里可以添加产品分析相关的逻辑
        Utils.showNotification('产品分析功能开发中...', 'info');
    }

    /**
     * 显示AI分析页面
     */
    showAIAnalysis() {
        console.log('显示AI分析页面');
        // 这里可以添加AI分析相关的逻辑
        Utils.showNotification('AI分析功能开发中...', 'info');
    }

    /**
     * 显示设置页面
     */
    showSettings() {
        console.log('显示设置页面');
        // 这里可以添加设置相关的逻辑
        Utils.showNotification('设置功能开发中...', 'info');
    }
}

// 导出仪表盘类
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Dashboard;
} 