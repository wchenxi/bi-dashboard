# 亚马逊电商BI看板

一个基于HTML、CSS和JavaScript开发的现代化BI看板，专门用于展示和分析亚马逊电商数据，并集成AI分析功能。

## 🚀 功能特性

### 📊 数据可视化
- **关键指标卡片**: 总销售额、订单数量、平均评分、转化率等核心指标
- **销售趋势图**: 支持7天、30天、90天的销售趋势分析
- **类别分布图**: 环形图展示各产品类别的销售占比
- **热销产品排行**: 实时更新的产品销量排行榜
- **数据表格**: 支持搜索、排序、分页的详细数据展示

### 🤖 AI智能分析
- **多维度分析**: 销售趋势、竞争分析、优化建议、销售预测
- **智能洞察**: 自动生成数据洞察和业务建议
- **快速分析**: 基于数据特征自动生成快速洞察
- **分析历史**: 保存和查看历史分析结果

### 🎨 现代化UI设计
- **响应式布局**: 完美适配桌面端和移动端
- **深色/浅色主题**: 支持主题切换和系统主题跟随
- **流畅动画**: 丰富的交互动画和过渡效果
- **直观操作**: 简洁易用的用户界面

### 📁 数据处理
- **Excel文件支持**: 支持.xlsx和.xls格式文件
- **智能列映射**: 自动识别和映射Excel列名
- **数据清洗**: 自动处理数据格式和异常值
- **导出功能**: 支持CSV和JSON格式数据导出

## 📁 项目结构

```
车载机架/
├── index.html              # 主页面
├── css/
│   ├── style.css           # 基础样式
│   └── dashboard.css       # 仪表盘专用样式
├── js/
│   ├── config.js           # 配置文件
│   ├── utils.js            # 工具函数
│   ├── dataProcessor.js    # 数据处理模块
│   ├── charts.js           # 图表管理模块
│   ├── aiService.js        # AI服务模块
│   ├── dashboard.js        # 仪表盘主模块
│   └── app.js              # 应用入口文件
├── BSR(Cradles(Current))-100-US.xlsx  # 示例数据文件
└── README.md               # 项目说明文档
```

## 🛠️ 技术栈

- **前端框架**: 原生JavaScript (ES6+)
- **图表库**: Chart.js
- **图标库**: Font Awesome
- **样式**: CSS3 + Grid/Flexbox
- **数据格式**: Excel (.xlsx/.xls), CSV, JSON
- **AI服务**: OpenAI GPT API (可配置)

## 🚀 快速开始

### 1. 环境要求
- 现代浏览器 (Chrome 80+, Firefox 75+, Safari 13+, Edge 80+)
- 支持ES6+的JavaScript环境
- 网络连接 (用于加载CDN资源)

### 2. 本地开发

1. **克隆或下载项目**
   ```bash
   # 如果使用Git
   git clone [项目地址]
   
   # 或者直接下载ZIP文件
   ```

2. **启动本地服务器**
   ```bash
   # 使用Python (推荐)
   python -m http.server 8000
   
   # 或使用Node.js
   npx serve .
   
   # 然后在浏览器中访问
   http://localhost:8000
   ```

3. **配置AI服务 (可选)**
   - 在浏览器控制台中执行:
   ```javascript
   // 设置OpenAI API密钥
   dashboard.aiService.setApiKey('your-api-key-here');
   ```

### 3. 在线部署

#### 方案一：GitHub Pages (推荐)
1. **运行部署脚本**
   ```bash
   # Windows用户
   deploy.bat
   
   # Linux/Mac用户
   chmod +x deploy.sh
   ./deploy.sh
   ```

2. **手动部署**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/你的用户名/仓库名.git
   git push -u origin main
   ```

3. **启用GitHub Pages**
   - 进入仓库设置 → Pages
   - Source选择"Deploy from a branch"
   - Branch选择"main"，文件夹选择"/ (root)"
   - 点击Save

#### 方案二：Netlify
1. 访问 https://netlify.com
2. 注册账号并登录
3. 将项目文件夹拖拽到部署区域
4. 自动获得在线访问地址

#### 方案三：Vercel
1. 访问 https://vercel.com
2. 注册账号并登录
3. 导入GitHub仓库或直接上传项目
4. 自动部署并生成访问链接

### 3. 使用说明

#### 数据导入
1. 准备Excel文件，包含以下列：
   - Product Name (产品名称)
   - Category (类别)
   - Sales (销售额)
   - Rating (评分)
   - Reviews (评论数)
   - BSR (Best Seller Rank)
   - Price (价格)
   - Date (日期)

2. 目前项目使用模拟数据，如需使用真实数据，请修改 `dashboard.js` 中的 `loadMockData()` 方法。

#### 功能使用
- **查看仪表盘**: 页面加载后自动显示数据概览
- **筛选数据**: 使用日期选择器和搜索框筛选数据
- **AI分析**: 点击"AI分析"按钮进行深度数据分析
- **导出数据**: 使用浏览器控制台执行 `dashboard.exportData('csv')`

## ⚙️ 配置说明

### AI服务配置
在 `js/config.js` 中配置AI服务：

```javascript
AI_SERVICE: {
    BASE_URL: 'https://api.openai.com/v1/chat/completions',
    API_KEY: '', // 需要用户配置
    MODEL: 'gpt-3.5-turbo',
    MAX_TOKENS: 1000
}
```

### 图表配置
可以自定义图表颜色、样式等：

```javascript
CHARTS: {
    COLORS: {
        PRIMARY: '#667eea',
        SECONDARY: '#764ba2',
        // ... 更多颜色
    }
}
```

## 🔧 自定义开发

### 添加新的图表类型
1. 在 `charts.js` 中添加新的图表方法
2. 在 `dashboard.js` 中调用新图表
3. 在HTML中添加对应的canvas元素

### 扩展数据处理
1. 在 `dataProcessor.js` 中添加新的数据处理方法
2. 在 `dashboard.js` 中集成新功能

### 自定义AI分析
1. 在 `aiService.js` 中添加新的分析类型
2. 修改提示词模板
3. 更新UI界面

## 📱 响应式设计

项目采用响应式设计，支持以下设备：
- **桌面端**: 1920px及以上
- **平板端**: 768px - 1919px
- **手机端**: 320px - 767px

## 🎨 主题定制

### 颜色主题
主要颜色变量在 `css/style.css` 中定义：

```css
:root {
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --background-color: #f5f7fa;
    --text-primary: #333333;
    --text-secondary: #666666;
}
```

### 深色主题
项目支持深色主题，可以通过以下方式切换：
- 系统主题跟随
- 手动切换
- 编程方式设置

## 🔒 安全说明

- API密钥存储在浏览器本地存储中
- 建议在生产环境中使用环境变量管理敏感信息
- 所有数据处理都在客户端进行，保护数据隐私

## 🐛 故障排除

### 常见问题

1. **图表不显示**
   - 检查Chart.js是否正确加载
   - 确认canvas元素存在且ID正确

2. **AI分析失败**
   - 检查API密钥是否配置
   - 确认网络连接正常
   - 查看浏览器控制台错误信息

3. **数据加载失败**
   - 检查数据格式是否正确
   - 确认文件编码为UTF-8
   - 查看控制台错误信息

### 调试模式
在浏览器控制台中执行以下命令查看应用状态：

```javascript
// 查看应用状态
console.log(app.getStatus());

// 查看仪表盘状态
console.log(dashboard);

// 查看当前数据
console.log(dashboard.currentData);
```

## 📈 性能优化

- 使用防抖和节流优化搜索和图表更新
- 图表数据缓存和懒加载
- 分页加载减少DOM操作
- 图片和资源压缩

## 🤝 贡献指南

欢迎提交Issue和Pull Request来改进项目！

### 开发规范
- 使用ES6+语法
- 遵循JavaScript标准规范
- 添加适当的注释
- 保持代码简洁可读

## 📄 许可证

本项目采用MIT许可证，详见LICENSE文件。

## 🌐 在线部署

### 部署选项

#### 1. GitHub Pages (免费)
- **优点**: 完全免费，自动HTTPS，易于维护
- **适用**: 个人项目、小型团队
- **地址**: `https://用户名.github.io/仓库名/`

#### 2. Netlify (免费)
- **优点**: 自动部署，自定义域名，CDN加速
- **适用**: 需要快速部署的项目
- **地址**: 自动生成，可自定义

#### 3. Vercel (免费)
- **优点**: 极速部署，自动优化，全球CDN
- **适用**: 需要高性能的项目
- **地址**: 自动生成，可自定义

### 部署注意事项

1. **Excel文件路径**: 确保Excel文件包含在部署包中
2. **CORS问题**: 部署后自动解决本地CORS限制
3. **HTTPS**: 所有平台都自动提供HTTPS证书
4. **缓存**: 部署后可能需要清除浏览器缓存

### 自定义域名
- GitHub Pages: 在仓库设置中配置
- Netlify/Vercel: 在平台设置中绑定
- 需要DNS解析配置

## 📞 联系方式

如有问题或建议，请通过以下方式联系：
- 提交GitHub Issue
- 发送邮件至 [your-email@example.com]

---

**注意**: 这是一个演示项目，生产环境使用前请进行充分测试和安全评估。 